
package trabalhojava2;

/**
 *
 * @author alann
 */
import javax.swing.JOptionPane;

public class ContaEspecial extends Contas {
    
    int limite;
    double multa;
    double novoSaldo, saldoDescontado;
    
   public void saqueEspecial(double valor) {
        novoSaldo = getSaldo() - valor;
        descontar(multa);
    }

    public void descontar(double multa) {
        saldoDescontado = (novoSaldo * multa) / 100;
        double soma = novoSaldo + saldoDescontado;
        setSaldo(soma);
    }

    public void tipoConta() {
        JOptionPane.showMessageDialog(null, "Conta especial");
    }
}