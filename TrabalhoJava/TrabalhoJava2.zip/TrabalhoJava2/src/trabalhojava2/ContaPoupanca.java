
package trabalhojava2;

/**
 *
 * @author alann
 */
import javax.swing.JOptionPane;

public class ContaPoupanca extends Contas {
    
    public void reajustar(double taxa){  //reajustar o saldo de acordo com a taxa informada
        double saldoAtual = this.getSaldo();
        double reajuste = saldoAtual * taxa;
        this.depositar(reajuste);
    }
    
  
    public void reajustar(){ //reajustar com a taxa de 10%
        double saldoAtual = this.getSaldo();
        double reajuste = saldoAtual * 0.1;
        this.depositar(reajuste);
    }
   
    public void tipoConta(){ //imprimir o tipo de conta
        JOptionPane.showMessageDialog(null, "Conta Poupança");
    }
    
    
}