/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhojava2;

/**
 *
 * @author alann
 */
import javax.swing.JOptionPane;

public class Contas {
    int numero;
    String nome;
    double saldo;

    public int getNumero() {
        return numero;
    }
    
    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    void depositar(double valor){
        this.saldo = this.saldo + valor;
    }
    
    boolean sacar(double valor){
        if (this.saldo>=valor){
            this.saldo-=valor;
            return(true);
        }
        else
            return false;
    }

    public double transferir(int conta1, int conta2, double valor) {
        if (saldo > valor) {
            saldo = saldo - valor;
        }
        return saldo;
    }

    public void tipoConta() {
        JOptionPane.showMessageDialog(null, "Conta Comum");
    }
    
}
