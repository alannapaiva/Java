/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula2.pkg2;

public class Carros {
    int Ano, Portas;
    double Preco;
    String Marca, Modelo;
    double verDesconto;
          
             
    public int getAno() {
        return Ano;
    }

    public void setAno(int Ano) {
        this.Ano = Ano;
    }

    public int getPortas() {
        return Portas;
    }

    public void setPortas(int Portas) {
        this.Portas = Portas;
    }

    public double getPreco() {
        return Preco;
    }

    public void setPreco(double Preco) {
        this.Preco = Preco;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }
    
    void verDesconto(double taxa){
       double precoDesconto = (this.Preco*taxa)/100;
       System.out.println("Preço com desconto é: " +precoDesconto);  
    }   
}
