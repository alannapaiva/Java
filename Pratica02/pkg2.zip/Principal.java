/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula2.pkg2;

import java.util.Scanner;


public class Principal {

    public static void main(String[] args) {
       Scanner ler = new Scanner(System.in);
        
        Carros obj1;
        Carros obj2;
        obj1 = new Carros();
        obj2 = new Carros();
        
        //Recebendo dados do Carro 1
        System.out.println("Insira os dados do Carro 1");
        System.out.print("Digite a marca do carro:");
        obj1.setMarca(ler.next());
      
        System.out.print("Digite o modelo do carro:");
        obj1.setModelo(ler.next());
      
        System.out.print("Digite o ano:");
        obj1.setAno(ler.nextInt());
        
        System.out.print("Digite a quantidade de portas:");
        obj1.setPortas(ler.nextInt());
         
        System.out.print("Digite o preço:");
        obj1.setPreco(ler.nextDouble());
       
       //Recebendo dados do Carro 2
        System.out.println("Insira os dados do Carro 2");
        System.out.print("Digite a marca do carro:");
        obj2.setMarca(ler.next());
      
        System.out.print("Digite o modelo do carro:");
        obj2.setModelo(ler.next());
      
        System.out.print("Digite o ano:");
        obj2.setAno(ler.nextInt());
        
        System.out.print("Digite a quantidade de portas:");
        obj2.setPortas(ler.nextInt());
         
        System.out.print("Digite o preço:");
        obj2.setPreco(ler.nextDouble());   
      
        //Recendo a Taxa de Desconto
        double taxa;
        System.out.print("Digite a taxa de desconto: ");
        taxa = ler.nextDouble();
        
        // Mostrando os dados do carro 1  
        System.out.println("\nDados do Carro 1");
        System.out.println("Marca é:" +obj1.Marca);
        System.out.println("Modelo do carro:" +obj1.Modelo);
        System.out.println("Ano do carro:" +obj1.Ano);        
        System.out.println("O carro possui:" +obj1.Portas+ " portas");  
        System.out.println("Preço do carro:" +obj1.Preco); 
        obj1.verDesconto(taxa);
        
       // Mostrando os dados do carro 2 
        System.out.println("\nDados do Carro 2");
        System.out.println("Marca é:" +obj2.getMarca());
        System.out.println("Modelo do carro:" +obj2.getModelo());
        System.out.println("Ano do carro:" +obj2.getAno());
        System.out.println("O carro possui:" +obj2.getPortas()+ " portas");  
        System.out.println("Preço do carro:" +obj2.getPreco()); 
        obj2.verDesconto(taxa);
        
//        System.out.println("Preço com desconto é: " +obj1.verDesconto); 
//        System.out.println("Preço com desconto é: " +obj2.verDesconto); 
       
    }
 }
    
